package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.Airport;

public interface AirportDao {
	
	public List<Airport> viewAirport();
	
}

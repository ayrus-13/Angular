/**
 * 
 */
package com.cg.frs.exception;

/**
 * @author: DEVANG
 * description:  
 * created date:
 * modified: 
 */
public class UserNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserNotFoundException() {
	}
	
	public UserNotFoundException(String message){
		super(message);
	}

}

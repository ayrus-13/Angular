/**
 * 
 */
package com.cg.frs.exception;

/**
 * @author: DEVANG
 * description:  
 * created date:
 * modified: 
 */
public class InvalidAirportException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public InvalidAirportException() {
	}
	
	public InvalidAirportException(String message){
		super(message);
	}

}

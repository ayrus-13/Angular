/**
 * 
 */
package com.cg.frs.exception;

/**
 * @author: DEVANG
 * description:  
 * created date:
 * modified: 
 */
public class FlightNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public FlightNotFoundException(){
		
	}
	
	public FlightNotFoundException(String message){
		super(message);
	}

}

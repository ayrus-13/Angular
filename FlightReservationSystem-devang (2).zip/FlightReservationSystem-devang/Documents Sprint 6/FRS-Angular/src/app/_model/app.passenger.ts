export class Passenger{

    pnrNumber:number;
    passengerName:string;
    passengerAge:number;
    passengerUIN:number;
    passengerState:boolean;

}